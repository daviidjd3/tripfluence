# TripFluence

App de vídeos turísticos con puntuaciones y mapa.

## Instalación

1. Instala Node.js y Expo CLI
2. Ejecuta `npm install`
3. Ejecuta `expo start`