// Entry point for React Native App
console.log('TripFluence App');